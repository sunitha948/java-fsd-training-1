package com.ust.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;


import com.ust.beans.Student;
import com.ust.dao.StudentDao;

@Controller
public class StudentContoller {
	@Autowired
	StudentDao dao;
	
	@RequestMapping("/studform")
	public String showform(Model m){  
    	m.addAttribute("command", new Student());
    	return "studform"; 
    }  
	
	@RequestMapping(value="/save",method = RequestMethod.POST)
	public String save(@ModelAttribute("stud") Student student){  
        dao.save(student);  
        return "redirect:/viewstud";
	}
	
	@RequestMapping("/viewstud")
	public String viewemp(Model m){  
        List<Student> list=dao.getStudents();  
        m.addAttribute("list",list);
        return "viewstud";
	}
	
		@RequestMapping(value="/editstud/{id}")
	    public String edit(@PathVariable int id, Model m){  
	        Student student=dao.getStudentById(id);  
	        m.addAttribute("command",student);
	        return "studeditform"; 
	    }
		
		@RequestMapping(value="/editsave",method = RequestMethod.POST)
		 public String editsave(@ModelAttribute("stud") Student student){  
		        dao.update(student);  
		        return "redirect:/viewstud";  
		    }
		
		@RequestMapping(value="/deletestud/{id}",method = RequestMethod.GET)
		  public String delete(@PathVariable int id){  
		        dao.delete(id);  
		        return "redirect:/viewstud";  
		    }
}
